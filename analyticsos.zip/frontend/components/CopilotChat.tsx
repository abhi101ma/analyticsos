// React chat UI
