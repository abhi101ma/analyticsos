// React dashboard component
